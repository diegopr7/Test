/*******************************************************************************/
/**
\file       app_scheduler.c
\brief      Multi-thread Task scheduler.
\author     Abraham Tezmol
\version    0.1
\date       09/09/2008
*/

/** Variable types and common definitions */
#include "system_samv71.h"

/** Scheduler function prototypes definitions */
#include "app_scheduler.h"
/** Tasks definition */
//#include "app_tasks.h"

/* GPIO configuration */
#include "board.h"
#include "pio.h"

/* -- Global Variables --------------------------------------------------------*/
uint8_t gu8Scheduler_Status;
uint8_t gu8Scheduler_Counter;
uint8_t gu8Scheduler_Thread_ID;
uint8_t gu8Scheduler_Thread_ID_Backup;
uint8_t u8_10ms_Counter;
uint8_t u8_50ms_Counter;
uint8_t u8_100ms_Counter;

/* GPIO configuration, one pin to every task, it will allow to perform the test
 * without modify code */
Pin apPins[enVar_NumOfTasks] =
{
     { PIO_PB3,  PIOB, ID_PIOB, PIO_OUTPUT_0, PIO_PULLUP } //EXT1 5   enVal_1ms
    ,{ PIO_PD28, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_PULLUP } //EXT1 9   enVal_2ms_a
    ,{ PIO_PB0,  PIOB, ID_PIOB, PIO_OUTPUT_0, PIO_PULLUP } //EXT1 13  enVal_2ms_b
    ,{ PIO_PD25, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_PULLUP } //EXT1 15  enVal_10ms
    ,{ PIO_PD20, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_PULLUP } //EXT1 17  enVal_50ms
    ,{ PIO_PD30, PIOD, ID_PIOD, PIO_OUTPUT_0, PIO_PULLUP } //EXT2 3   enVal_100ms
};


/* d) Crear un arreglo tipo estructura que contenga todas las tareas definidas:
 * 1ms, 2ms_a, 2ms_b, 10ms, 50ms, 100ms. */
tstTaskType astTaskList[] =
{
    /*  enTaskName          pvTask                          enTaskState (initial condition) */
    { enVal_1ms,            NULL,                           enVal_Idle },
    { enVal_2ms_a,          NULL,                           enVal_Idle },
    { enVal_2ms_b,          NULL,                           enVal_Idle },
    { enVal_10ms,           vfnLedCtrl_BlinkingPattern,     enVal_Idle },
    { enVal_50ms,           NULL,                           enVal_Idle },
    { enVal_100ms,          NULL,                           enVal_Idle }
};

/* -- Local prototypes --------------------------------------------------------*/
/* e) Crear las siguientes funciones:  */
/* Activa la tarea que se pasa por referencia */
static void vfnTaskActivate( tstTaskType * task );

/* Ejecuta la tarea que se pasa por referencia */
static void vfnTaskStart( tstTaskType * task );

/* Termina la tarea que se pasa por referencia */
static void vfnTaskTerminate( tstTaskType * task );



/*******************************************************************************/
/**
* \brief    Scheduler - Periodic Interrup Timer Initialization
* \author   Abraham Tezmol
* \param    void
* \return   void
* \todo     
*/
void vfnScheduler_Init(void)
{   
    /* Init Global and local Task Scheduler variables */
    gu8Scheduler_Counter = 0;   
    gu8Scheduler_Thread_ID = NO_TASK_PENDING;
    u8_10ms_Counter = 0;
    u8_50ms_Counter = 0;
    u8_100ms_Counter = 0;
    gu8Scheduler_Status = TASK_SCHEDULER_INIT;
}

/*******************************************************************************/
/**
* \brief    Scheduler Start - Once time base is armed, start execution of   \n
            Multi-thread Round Robin scheduling scheme.                     \n
            This function requires prior execution of "vfnScheduler_Init"
* \author   Abraham Tezmol
* \param    void
* \return   void
* \todo     
*/
void vfnScheduler_Start(void)
{
    if (SysTick_Config(SystemCoreClock / TASK_SCHEDULER_BASE_FREQ))
    {
        while (1);
    }
    gu8Scheduler_Status = TASK_SCHEDULER_RUNNING;

    /* Init pin configuration to measurement */
    PIO_Configure(&apPins[0],enVar_NumOfTasks);
}

/*******************************************************************************/
/**
* \brief    Scheduler Stop - stop execution of Multi-thread Round Robin scheduling scheme.
* \author   Abraham Tezmol
* \param    void
* \return   void
* \todo     
*/
void vfnScheduler_Stop(void)
{  
    /* Update scheduler status accordingly */
    gu8Scheduler_Status = TASK_SCHEDULER_HALTED;
}

/*******************************************************************************/
/**
* \brief    Multi-thread round robin task Scheduler  (non-preemtive)        \n
            It calls the different tasks based on the status of             \n   
            "gu8Scheduler_Thread_ID". This variable is modified by          \n
            ISR "vfnScheduler_PIT_Isr"                                        \n
            List of tasks shall be defined @ "tasks.h" file
* \author   Abraham Tezmol
* \param    void
* \return   void
* \todo     
*/
void vfnTask_Scheduler(void)
{
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*  1ms execution thread - used to derive two execution threads:                */
    /*  a) 1ms thread (high priority tasks)                                         */
    /*  b) 100ms thread (lowest priority tasks)                                     */
    /*  As any other thread on this scheduler, all tasks must be executed in <=500us*/
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/   
    if ((gu8Scheduler_Thread_ID == TASKS_1_MS) || (gu8Scheduler_Thread_ID == TASKS_100_MS))
    {
        /* Make a copy of scheduled task ID */
        gu8Scheduler_Thread_ID_Backup = gu8Scheduler_Thread_ID;
        
        vfnTaskStart(&astTaskList[enVal_1ms]);
        vfnTaskTerminate(&astTaskList[enVal_1ms]);
        if (gu8Scheduler_Thread_ID == TASKS_100_MS)
        {
            vfnTaskStart(&astTaskList[enVal_100ms]);
            vfnTaskTerminate(&astTaskList[enVal_100ms]);
        }
        /* Verify that thread execution took less than 500 us */
        if (gu8Scheduler_Thread_ID_Backup == gu8Scheduler_Thread_ID)
        {
             /* In case execution of all thread took less than 500us */
            gu8Scheduler_Thread_ID = NO_TASK_PENDING;
        }
        else
        {
            gu8Scheduler_Status = TASK_SCHEDULER_OVERLOAD_1MS;
        }
    }
    else
    {
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        /*  2ms execution thread - used to derive two execution threads:                */
        /*  a) 2ms group A thread (high priority tasks)                                 */
        /*  b) 50ms thread (second lowest priority tasks)                               */
        /*  As any other thread on this scheduler, all tasks must be executed in <=500us*/
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        if ((gu8Scheduler_Thread_ID == TASKS_2_MS_A) || (gu8Scheduler_Thread_ID == TASKS_50_MS))
        {
            /* Make a copy of scheduled task ID */
            gu8Scheduler_Thread_ID_Backup = gu8Scheduler_Thread_ID;
            
            vfnTaskStart(&astTaskList[enVal_2ms_a]);
            vfnTaskTerminate(&astTaskList[enVal_2ms_a]);
            if (gu8Scheduler_Thread_ID == TASKS_50_MS)
            {
                vfnTaskStart(&astTaskList[enVal_50ms]);
                vfnTaskTerminate(&astTaskList[enVal_50ms]);
            }
            /* Verify that thread execution took less than 500 us */
            if (gu8Scheduler_Thread_ID_Backup == gu8Scheduler_Thread_ID)
            {
                 /* In case execution of all thread took less than 500us */
                gu8Scheduler_Thread_ID = NO_TASK_PENDING;
            }
            else
            {
                gu8Scheduler_Status = TASK_SCHEDULER_OVERLOAD_2MS_A;
            }
        }
        else
        {
            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
            /*  2ms execution thread - used to derive two execution threads:                */
            /*  a) 2ms group B thread (high priority tasks)                                 */
            /*  b) 10ms thread (medium priority tasks)                                      */
            /*  As any other thread on this scheduler, all tasks must be executed in <=500us*/
            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
            if ((gu8Scheduler_Thread_ID == TASKS_2_MS_B) || (gu8Scheduler_Thread_ID == TASKS_10_MS))
            {
                /* Make a copy of scheduled task ID */
                gu8Scheduler_Thread_ID_Backup = gu8Scheduler_Thread_ID;
                
                vfnTaskStart(&astTaskList[enVal_2ms_b]);
                vfnTaskTerminate(&astTaskList[enVal_2ms_b]);
                if (gu8Scheduler_Thread_ID == TASKS_10_MS)
                {
                    vfnTaskStart(&astTaskList[enVal_10ms]);
                    vfnTaskTerminate(&astTaskList[enVal_10ms]);
                }
                 /* Verify that thread execution took less than 500 us */
                if (gu8Scheduler_Thread_ID_Backup == gu8Scheduler_Thread_ID)
                {
                    /* In case execution of all thread took less than 500us */
                    gu8Scheduler_Thread_ID = NO_TASK_PENDING;
                }
                else
                {
                    gu8Scheduler_Status = TASK_SCHEDULER_OVERLOAD_2MS_B;
                }
            }
        }
    }        
}

/*******************************************************************************/
/**
* \brief    Periodic Interrupt Timer Service routine.                            \n
            This interrupt is the core of the task scheduler.                   \n
            It is executed every 500us                                          \n
            It defines 3 basic threads from which other 3 threads are derived:  \n
            a) 1ms thread (basic) ->  100ms thread (derived)                    \n
            b) 2ms A thread (basic)-> 50ms thread (derived)                     \n
            c) 2ms B thread (basic)-> 10ms thread (derived)                     \n
            It partitions core execution time into time slices (500us each one).\n 
            This arrangement assures core will have equal task loading across time.\n   
            For more information on how time slice is assigned to each thread,  \n
            refer to file "S12X Task Scheduler Layout.xls"
* \author   Abraham Tezmol
* \param    void
* \return   void
* \todo
*/

void SysTick_Handler(void)
{
    /*-- Update scheduler control variable --*/
    gu8Scheduler_Counter++;

    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    /*  1ms execution thread - used to derive two execution threads:                */
    /*  a) 1ms thread (highest priority tasks)                                      */
    /*  b) 100ms thread (lowest priority tasks)                                     */
    /*  As any other thread on this scheduling scheme,                              */
    /*  all tasks must be executed in <= 500us                                      */
    /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
    if ((gu8Scheduler_Counter & 0x01) == 0x01)
    {
        u8_100ms_Counter++;

        vfnTaskActivate(&astTaskList[enVal_1ms]);

        /*-- Allow 100 ms periodic tasks to be executed --*/
        if (u8_100ms_Counter >= 100)
        {
            gu8Scheduler_Thread_ID = TASKS_100_MS;
            vfnTaskActivate(&astTaskList[enVal_100ms]);
            u8_100ms_Counter = 0;
        }
        /*-- Allow 1 ms periodic tasks to be executed --*/
        else
        {
            gu8Scheduler_Thread_ID = TASKS_1_MS;
        }
    }
    else
    {
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        /*  2ms execution thread - used to derive two execution threads:                */
        /*  a) 2ms group A thread (high priority tasks)                                 */
        /*  b) 50ms thread (second lowest priority tasks)                               */
        /*  As any other thread on this scheduling scheme,                              */
        /*  all tasks must be executed in <= 500us                                      */
        /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
        if ((gu8Scheduler_Counter & 0x02) == 0x02)
        {
            u8_50ms_Counter++;
            vfnTaskActivate(&astTaskList[enVal_2ms_a]);
            /*-- Allow 50 ms periodic tasks to be executed --*/
            if (u8_50ms_Counter >= 25)
            {
                vfnTaskActivate(&astTaskList[enVal_50ms]);
                gu8Scheduler_Thread_ID = TASKS_50_MS;
                u8_50ms_Counter = 0;
            }
            /*-- Allow 2 ms group A periodic tasks to be executed --*/
            else
            {
                gu8Scheduler_Thread_ID = TASKS_2_MS_A;
            }
        }
        else
        {
            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
            /*  2ms execution thread - used to derive two execution threads:                */
            /*  a) 2ms group B thread (high priority tasks)                                 */
            /*  b) 10ms thread (medium priority tasks)                                      */
            /*  As any other thread on this scheduling scheme,                              */
            /*  all tasks must be executed in <= 500us                                      */
            /*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~*/
            if ((gu8Scheduler_Counter & 0x03) == 0x00)
            {
                u8_10ms_Counter++;
                vfnTaskActivate(&astTaskList[enVal_2ms_b]);
                /*-- Allow 10 ms periodic tasks to be executed --*/
                if (u8_10ms_Counter >= 5)
                {
                    vfnTaskActivate(&astTaskList[enVal_10ms]);
                    gu8Scheduler_Thread_ID = TASKS_10_MS;
                    u8_10ms_Counter = 0;
                }
                /*-- Allow 2 ms group B periodic tasks to be executed --*/
                else
                {
                    gu8Scheduler_Thread_ID = TASKS_2_MS_B;
                }
            }
        }
    }
}


/* -- Local Functions --------------------------------------------------------*/
static void vfnTaskActivate( tstTaskType * task )
{
    /* Changing task state */
    task->enTaskState = enVal_Ready;

    /* Setting HIGH in corresponding pin task */
    PIO_Set(&apPins[task->enTaskName]);
}

static void vfnTaskStart( tstTaskType * task )
{
    /* Changing task state */
    task->enTaskState = enVal_Running;
    
    /* Setting LOW in corresponding pin task */
    PIO_Clear(&apPins[task->enTaskName]);

    /* Checking if there is something to invoc */
    if(NULL != task->pvTask)
    {
        task->pvTask();
    }
}

static void vfnTaskTerminate( tstTaskType * task )
{
    /* Changing task state */
    task->enTaskState = enVal_Idle;
}
