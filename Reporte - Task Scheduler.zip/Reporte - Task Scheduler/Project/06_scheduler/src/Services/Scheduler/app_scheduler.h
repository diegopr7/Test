/*******************************************************************************/
/**
\file       app_scheduler.h
\brief      Task scheduler function prototypes
\author     Abraham Tezmol
\version    0.1
\date       09/09/2008
*/

#ifndef APP_SCHEDULER_H        /*prevent duplicated includes*/
#define APP_SCHEDULER_H

/*-- Includes ----------------------------------------------------------------*/

#include "compiler.h"
#include "led_ctrl.h"
/*-- Types Definitions -------------------------------------------------------*/

/* a) Definir una enumeraci�n con la lista de las tareas existentes */
typedef enum
{
     enVal_1ms
    ,enVal_2ms_a
    ,enVal_2ms_b
    ,enVal_10ms
    ,enVal_50ms
    ,enVal_100ms

    /* Leave at final */
    ,enVar_NumOfTasks
}tenTasksLists;

/* b) Definir una enumeraci�n con la lista de los estados del
 * ciclo de vida de las tareas */
typedef enum
{
     enVal_Idle     = 0x00
    ,enVal_Ready
    ,enVal_Running
}tenTaskState;

/* Puntero al tipo de funcion a ejecutar */
typedef void (*tpvTask)(void);

/* c) Crear un tipo de dato estructura que contenga los siguientes campos:
 * Nombre de la tarea (tipo enumeraci�n del inciso a ),
 * apuntador a funci�n a la tarea a ejecutar,
 * estado de la tarea (tipo enumeraci�n del inciso b ). */
typedef struct
{
    tenTasksLists  enTaskName;
    tpvTask        pvTask;
    tenTaskState   enTaskState;
}tstTaskType;

/*-- Defines -----------------------------------------------------------------*/

/* Task Scheduler state machine status definitions */
#define NO_TASK_PENDING     0x00u
#define TASKS_1_MS          0x01u
#define TASKS_2_MS_A        0x02u
#define TASKS_2_MS_B        0x03u
#define TASKS_10_MS         0x04u
#define TASKS_50_MS         0x05u
#define TASKS_100_MS        0x06u

/* Global Task Scheduler Status definitions */
#define TASK_SCHEDULER_INIT             0x00u   
#define TASK_SCHEDULER_RUNNING          0x01u
#define TASK_SCHEDULER_OVERLOAD_1MS     0x02u
#define TASK_SCHEDULER_OVERLOAD_2MS_A   0x03u
#define TASK_SCHEDULER_OVERLOAD_2MS_B   0x04u
#define TASK_SCHEDULER_HALTED           0xAAu


/*-- Macros ------------------------------------------------------------------*/
#define TASK_SCHEDULER_BASE_FREQ        2000


/*-- Function Prototypes -----------------------------------------------------*/

/** Sheduler Initalization (arming) */
void vfnScheduler_Init(void);

/** Scheduler kick-off function */
void vfnScheduler_Start(void);

/** Scheduler stop function */
void vfnScheduler_Stop(void);

/** Multi-thread round robin task scheduler */
void vfnTask_Scheduler(void);

/*******************************************************************************/

#endif /* APP_SCHEDULER_H */
